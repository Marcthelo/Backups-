<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RSP - Página Inicial </title>
    <!--LINKS INICIO-->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0"
    />
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="../../imgs/rsp2.ico" type="image/x-icon">
    <!--LINKS FIM-->
  </head>
  <body>
    <?php 
    session_start();
    ?>
    <!-- Cabeçalho -->
    <header>
      <?php
      if ((!isset($_SESSION['cpf']) == true) and (!isset($_SESSION['cnpj'])) and (!isset($_SESSION['senha'])) and (!isset($_SESSION['email'])) and (!isset($_SESSION['nome']))) {
        unset($_SESSION['cpf']);
        unset($_SESSION['cnpj']);
        unset($_SESSION['senha']);
        unset($_SESSION['email']);
        unset($_SESSION['nome']);
      }

      $logado = $_SESSION['nome'];
      ?>
      <!-- Header em Flex Display (Elementos em Ordem e Blocos) -->
      <div id="logo"><img id="ft" src="../../imgs/rsp2.png" alt="Foto-Logo" /></div>
      <!-- Logo fit-content só seu conteúdo dentro -->
      <div id="menuDiv">
        <button
          onclick="mostrarMenu()"
          class="menuBotaoDesativo"
          id="menuBotao"
        >
          <img id="menuImagem" src="../../imgs/menu.png" />
        </button>
        <div id="departamentosDiv" class="departamentosDesativo">
          <div id="departamentos1" class="departamentosDivInterior">
            <p> <a href="PRODUTOSHT(2).php" id="corA" class="corA"> Carros </a></p>
           <a  id="corA" class="corA" href="PRODUTOSHT(2).php"><p>Tratores</p></a> 
           <a  id="corA" class="corA" href="PRODUTOSHT(2).php"><p>Caminhões</p></a>
           <a  id="corA" class="corA" href="PRODUTOSHT(2).php"><p>Motocicleta</p></a> 
           <a  id="corA" class="corA" href="PRODUTOSHT(2).php"><p>Motonetas</p></a> 
          </div>
          <div id="departamentos2" class="departamentosDivInterior"></div>
        </div>
      </div>

      <!-- Script dá as classes necessárias pros elementos necessários -->
      <!-- Basicamente desativando e ativando as classes que dão -->
      <!-- O visual para o menu de departamentos aparecer visível -->
      <script>
        function mostrarMenu() {
          document.getElementById("menuDiv").classList.toggle("menuAtivo");
          document
            .getElementById("menuBotao")
            .classList.toggle("menuBotaoDesativo");
          document
            .getElementById("departamentosDiv")
            .classList.toggle("departamentosDesativo");
        }
      </script>

      <h2 id="titulo">TODOS OS DEPARTAMENTOS</h2>
      <!-- Título usa proporção de fonte (em) métrica importante, usem muito -->
      <!-- Barra Simples: Bordas com radius, placeholder é o texto que aparece sempre -->
      <!-- Icone de pesquisa, só baixar da internet um icone, colocar no src -->
      <!-- Se for jpeg coloca mix-blend-mode: multiply que tira o fundo branco -->
      <!-- Colocar o cursor: pointer para parecer "clicável" -->
      <div id="barraPesquisaDiv">
        <!-- Div da barra de pesquisa é flex -->
        <!-- Usamos isso para botar o icone em posição absoluta -->
        <!-- Fácil guiar o ícone pro final pra ficar em cima da barra só usando -->
        <!-- justify-content: end na div -->
        <input
          type="text"
          name="text"
          class="barraPesquisa"
          placeholder="Pesquisar"
        />
        <img id="pesquisaIcone" src="../../imgs/lupa.png" />
      </div>

<!-- MENU DE PEDIDOS -->
      <div class="menuPedidos">
        <ul class="departamentosPedidos">
          <li onclick="toggleSubMenu('department1')"> <h2> PEDIDOS </h2> </li>
          <ul id="department1" class="sub-menu2">
            <li> Pedido 1 </li>
            <li> Pedido 2 </li>
            <li> Pedido 3 </li>
      </div>
      <script>
        function toggleSubMenu(departamentoId) {
          var subMenu = document.getElementById(departamentoId);
          if (subMenu.style.display === 'block') {
            subMenu.style.display = 'none';
          } else {
            subMenu.style.display = 'block';
          }
        }
      </script>
          <?php 
      echo "<h1>Bem Vindo(a) <u>$logado</u></h1>";
      ?>
    <div id="entrar">
      <h2 id="entrarBotao"> <a href="../../php-server/FormulariosLogin/sair.php" id="corB" class="corB"> SAIR  </a> </h2>
    </div>
      
      <!-- Abrindo o segundo menu (pedidos), explicado o funcionamento acima -->
 
    </header>
    <!-- Section ajuda entender o seção do interior do site -->
    <!-- Funciona igual uma div -->
    <!-- Damos display flex para começarmos alinhar os elementos dentro -->
    <!-- Colocamos flex-direction em column, queremos que a ordem dos elementos seja em vertical (Cima pra baixo) -->
    <section id="corpo">
      <div id="carroselDiv">
        <div id="carrosel">
          <img class="carroselImagem" src="../../imgs/carrosel_tudo.png" />
          <img class="carroselImagem" src="../../imgs/carrosel_tudo.png" />
          <img class="carroselImagem" src="../../imgs/carrosel_tudo.png" />
        </div>
        <div id="carroselPaginas"></div>
      </div>

      <!-- Podemos colocar mais uma div em flex para alinhar em flex-direciton row -->
      <!-- Agora podemos colocar os veículos em horizontal fácilmente -->
      <div id="veiculosDiv">
        <div class="veiculoCirculo">
          <img class="veiculoImagem" src="../../imgs/automoveis.png" />
          <p class="veiculoDescricao"> Automovéis </p>
        </div>
        <div class="veiculoCirculo">
          <img class="veiculoImagem" src="../../imgs/caminhoes.png" />
          <p class="veiculoDescricao">Caminhões</p>
        </div>
        <div class="veiculoCirculo">
          <img class="veiculoImagem" src="../../imgs/tratores.png" />
          <p class="veiculoDescricao">Tratores</p>
        </div>
        <div class="veiculoCirculo">
          <img class="veiculoImagem" src="../../imgs/motocicleta.png" />
          <p class="veiculoDescricao">Motocicleta</p>
        </div>
        <div class="veiculoCirculo">
          <img class="veiculoImagem" src="../../imgs/motonetas.png" />
          <p class="veiculoDescricao">Motonetas</p>
        </div>
      </div>

      <h2 id="sobreTitulo">SOBRE NÓS</h2>
      <div id="sobreTexto">
        <div id="sobreTextoSecundario" class="aboutBloco"></div>
        <div id="sobreTextoTerciario" class="aboutBloco">
          Recondionadora de Peças São Paulo, uma empresa dedicada à remanufatura de peças automotivas, com foco na excelência, sustentabilidade e inovação. Fundada com a missão de oferecer alternativas econômicas e ecologicamente responsáveis aos nossos clientes, nossa empresa se orgulha de ser líder no setor de recondicionamento de peças.
        </div>
      </div>
      <h2 id="sociosTitulo">SÓCIOS</h2>
      <div id="sociosDiv">
        <div class="sociosItem">
          <div class="sociosCirculo"></div>
          <p class="sociosNome">SÓCIO 1</p>
        </div>
        <div class="sociosItem">
          <div class="sociosCirculo"></div>
          <p class="sociosNome">SÓCIO 2</p>
        </div>
        <div class="sociosItem">
          <div class="sociosCirculo"></div>
          <p class="sociosNome">SÓCIO 3</p>
        </div>
        <div class="sociosItem">
          <div class="sociosCirculo"></div>
          <p class="sociosNome">SÓCIO 4</p>
        </div>
      </div>

      <h2 id="colaboradoresTitulo">COLABORADORES</h2>
      <div class="colaboradoresDiv">
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 1</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 2</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 3</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 4</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 5</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 6</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 7</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 8</p>
        </div>
        <div class="colaboradoresItem">
          <div class="colaboradoresCirculo"></div>
          <p class="colaboradoresNome">COLABORADOR 9</p>
        </div>
      </div>
      <div id="cardsDiv">
        <div class="card">
          <h3 class="cardTitulo">MISSÃO</h3>
          <div class="cardTexto"> <h4> " Prestar assistência no ramo automotivo, através do recondicionamento de peças, 
            garantindo o seu perfeito funcionamento, maior durabilidade, e segurança em parcerias com nossos
             clientes e colaboradores. " </h4>
          </div>
        </div>
        <div class="card">
          <h3 class="cardTitulo">VISÃO</h3>
          <div class="cardTexto"> <h4> " Nossa visão é sermos reconhecidos como líderes globais em soluções sustentáveis para a indústria automotiva, redefinindo padrões de qualidade e inovação no recondicionamento de peças. " </h4></div>
        </div>
        <div class="card">
          <h3 class="cardTitulo">PROCESSO</h3>
          <div class="cardTexto"> <h4> "Seguimos um processo rigoroso e detalhado para garantir que cada peça remanufaturada atenda aos mais altos padrões de qualidade e desempenho. Nosso processo de remanufatura pode ser resumido nas seguintes etapas. "</h4></div>
        </div>
      </div>
    </section>
    <footer id="footer">
      <div class="blocoContato">
        <img class="iconeContato" />
        <p class="textoContato">WHATSAPP</p>
      </div>
      <div class="blocoContato">
        <img class="iconeContato" />
        <p class="textoContato">ENDEREÇO</p>
      </div>
      <div class="blocoContato">
        <img class="iconeContato" />
        <p class="textoContato">DIREITOS AUTORAIS</p>
      </div>
    </footer>
  </body>
</html>
<script>
  // Aqui se define variáveis úteis
  // A div que contém os bloquinhos que indicam a página atual do carrosel
  const carroselPaginas = document.getElementById("carroselPaginas");
  // Cria um bloquinho que indica a página atual, estes bloquinhos vai serão divs
  const paginaIndicador = document.createElement("div");
  // Pega a div do carrosel em si
  const carrosel = document.getElementById("carrosel");
  // Pega as imagens que estão dentro da div do carrosel
  const carroselImages = document.getElementsByClassName("carroselImagem");

  // Criar indicadores da página atual ==
  // Dá a classe para o bloquinho que indica a página (é uma classe de css normal lá em cima ^^)
  paginaIndicador.classList.add("carroselPaginaIndicador");
  // Cria clones do bloquinho criado, igual a quantidade de imagens no carrosel (carroselImages.length)
  // Adiciona eles como filhos do carroselPaginas, ou seja, estarão dentro da div dos bloquinhos carroselPaginas
  // OBS: Quando você cria um elemento no javascript (createElement()) ele não aparece diretamente no html!
  // é necessário especificar de quem ele é filho (qual elemento ele estará dentro, 'elemento.appendChild(filho)')
  for (let i = 0; i < carroselImages.length; i++) {
    carroselPaginas.appendChild(paginaIndicador.cloneNode(true));
  }
  // Por fim, PEGA todos os bloquinhos criados numa variável lista só.
  const paginaIndicadores = document.getElementsByClassName(
    "carroselPaginaIndicador"
  );
  // Toggle no primeiro bloquinho (0) pois a primeira imagem que aparece é a primeira (0) também
  paginaIndicadores[0].classList.toggle("carroselPaginaIndicadorAtivo");
  // Fazer scrollagem automática
  // Diz que a imagem que mostra atualmente é a primeira (0)
  let currentImage = 0;
  // Cria um loop que executa a cada intervalo de 4 segundos. (4000 porque está em milisegundos)
  // () = > {} é um jeito fácil de criar uma função no javascript sem precisar de function, apenas ()
  // Se pode atribuir a uma váriavel, tipo myFunction = () => {//fazalgo...} ou só passar como parâmetro
  // tipo como passamos em setInterval(), pois é a função que executa a cada intervalo de 4 segundos
  setInterval(() => {
    // Pega as dimensões do carrosel e sua posição de uma imagem no carrosel, tudo dentro dessa boundBox
    // É importante que esta linha esteja dentro do intervalo pois a posição e dimensão muda toda hora
    // Pega sempre da imagem 0 pois todas imagens tem a mesma largura e altura no nosso css, ent não faz diferença
    const boundBox = carroselImages[0].getBoundingClientRect();
    // Aumenta a imagem atual em 1 (se antes era 0, a primeira, agora é a segunda, 2)
    currentImage += 1;
    // Se a imagem atual é igual ao tamanho da lista das imagens do carrosel, quer dizer que este contador
    // currentImage passou da quantidade de imagens que existem
    if (currentImage === carroselImages.length) {
      // Fazemos a imagem atual ser a primeira (0) denovo.
      currentImage = 0;
      // Fazemos o último bloquinho indicador levar toggle da classe que deixa ele ativo, pois sabemos
      // que já que voltamos pro inicio, o último ativo era o último bloquinho
      paginaIndicadores[paginaIndicadores.length - 1].classList.toggle(
        "carroselPaginaIndicadorAtivo"
      );
      // Fazemos o bloquinho indicador da primeira imagem ter o css de ativo
      paginaIndicadores[0].classList.toggle("carroselPaginaIndicadorAtivo");
      // Fazemos o carrosel scrollar para o ínicio (posição 0 na esquerda), logo primeira imagem
      // Behavior smooth deixa a animação fluída, em vez de ir direto sem efeito/transição
      carrosel.scrollTo({ left: 0, behavior: "smooth" });
    } else {
      // Aqui só fazemos o bloquinho anterior (currentImage - 1) perder o css de ativo que ele tem
      paginaIndicadores[currentImage - 1].classList.toggle(
        "carroselPaginaIndicadorAtivo"
      );
      // Aqui fazemos o bloquinho da imagem atual ganhar o css de ativo
      paginaIndicadores[currentImage].classList.toggle(
        "carroselPaginaIndicadorAtivo"
      );
      // Scrollamos o carrosel em eixo horizontal equivalente a largura da imagem, ou seja
      // o suficiente para scrollar o suficiente até a imagem anterior sumir a nova estar no lugar
      carrosel.scrollBy({ left: boundBox.width, behavior: "smooth" });
      // Nota: Passa-se em scrollBy() (a função de scrollar) um objeto com os atributos da 'scrollação'
      // Um objeto é um conjunto de chaves e valores dentro de chaves { }
      // Objetos tem formatos diferentes, no caso do scrollBy ele tem vários, como left (scrollar horizontal)
      // top (scrollar vertical), behavior (como vai ser o efeito do scroll), etc.
      // Só passamos left e behavior porque é o que precisamos.
    }
  }, 4000); // Lembra, <-- milisegundos
</script>