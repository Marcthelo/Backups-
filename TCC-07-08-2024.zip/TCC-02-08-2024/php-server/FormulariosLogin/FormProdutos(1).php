<!DOCTYPE html>
<html lang="pt-br">
<head>
<style>
        a{
            text-decoration: none;
            color: rgb(255, 0, 0);
        }

        body {
            background-color:#818181;
            background-image: url("../../imgs/fundo1.png");
            background-size: cover;
        }

        fieldset {
            background-color: #B40000;
            border: solid #FF0000;
            border-radius: 9%;
            border-width: 20px;
            width: 15%;
            height: 60%;
            align-items: center;
            margin-left: 40%;
           margin: auto;
        }
 
        .inputBox {
            display: inline;
        }

        input {
            background-color: #FFFFFF;
            border-radius: 9%;
            margin-left: 2%;
            border-color: #FFFFFF;
            margin-left: 18%;
           
        }

        label {
            color: #f0f0f0;
            text-decoration: bold;
            margin: auto;
        
            margin-top: 0%;
            border-radius: 30%;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }

        button {
            color: #ff0000;
            border-radius: 9%;
            margin-left: 20%
            
        }
 
        legend {
            margin-top: 10%;
            color: #ffffff;
            border-radius: 30%;
            margin-left: 20%
        }
        #botoes {
            display: flex;
        }

        p {
            color: #9F9F9F;
            border-radius: 30%;
            font-size: 30%;
            margin-left: 2%
        }
        #button {
            color: #ff0000;
            border-radius: 9%;
            margin-left: 20%
            
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../../imgs/rsp2.ico" type="image/x-icon">
    <title>Produto(1)</title>
</head>
<body>
    <?php 
     
   if (isset($_POST['submit'])) {
         // Incluir arquivo de configuração
         include_once('config.php');

         // Recebe os dados do formulário
         $nome_produto = $_POST['nome_produto'];
         $img_produto = $_POST['img_produto']; // Deve ser uma URL da imagem
         $descricao = $_POST['descricao'];
         $tipo_fabricante = $_POST['tipo_fabricante'];
         $peca = $_POST['peca'];
         $qtd_volts = $_POST['qtd_volts'];
     
         
         // Prepara a inserção no SQL
         $sql = "INSERT INTO produtos (nome_produto, img_produto, descricao, tipo_fabricante, peca, qtd_volts) 
                            VALUES ('$nome_produto','$img_produto','$descricao','$tipo_fabricante','$peca','$qtd_volts')";
// Executa a consulta
if (mysqli_query($conexao, $sql)) {
    echo "<b style='color:green;';>Produto cadastrado com sucesso!<b/>";
} else {
    echo "Erro ao cadastrar produto: " . mysqli_error($conexao);
}
   }
     ?>
     
    <fieldset>
        <legend><h2><b>Produtos</b></h2></legend>
        <form method="POST" action="FormProdutos(1).php" enctype="multipart/form-data">
                <div class="inputBox">
                    <label for="nome_produto">Produto</label>
                    <select required name="nome_produto" id="nome_produto"> <!--required-->
                   <option value="">Selecione</option>
                    <option value="CARRO">Carro</option>
                    <option value="TRATOR">Trator</option>
                    <option value="CAMINHÃO">Caminhão</option>
                    <option value="MOTO">Moto</option>
                    <option value="MOTONETA">Motoneta</option>
                    </select>
                    <br> <br>
                </div>
                <div class="inputBox">
                <label for="img_produto">Image URL:</label>
                <input type="text" id="img_produto" name="img_produto" required>
                </div>
                <br><br>
                <div class="inputBox">
                    <label for="descricao">Descrição</label>
                    <input required type="text" name="descricao" id="descricao" class="inputProduto"  />
                </div>
                <br><br>
                <div class="inputBox">
                    <label for="tipo_fabricante">Fabricante</label>
                    <select required name="tipo_fabricante" id="tipo_fabricante">
                        <option value="">Selecione</option>
                        <option value="BOSCH">BOSCH</option>
                        <option value="DELCO_REMY">DELCO REMY</option>
                        <option value="DENSO">DENSO</option>
                        <option value="HITACHI">HITACHI</option>
                        <option value="ISKRA">ISKRA</option>
                        <option value="MAGNETI_MARELI">MAGNETI MARELI</option>
                        <option value="MITSUBISHI">MITSUBISHI</option>
                        <option value="MOTORCRAFT">MOTORCRAFT</option>
                        <option value="PRESTOLITE_LUC">PRESTOLITE/LUC</option>
                        <option value="VALEO">VALEO</option>
                        <option value="WAPSA">WAPSA</option>
                    </select>
                </div>
                <br> <br>
                <div class="inputBox">
                    <label for="peca">Peça</label>
                    <select required name="peca" id="peca">
                        <option value="">Selecione</option>
                        <option value="INDUZIDO">INDUZIDO</option>
                        <option value="ESTATOR">ESTATOR</option>
                        <option value="ROTOR">ROTOR</option>
                        <option value="BOBINA">BOBINA</option>
                        <option value="AUTOMÁTICO">AUTOMÁTICO</option>
                        <option value="IMPULSOR">IMPULSOR</option>
                        <option value="CHAVES_DE_SETAS">CHAVES DE SETAS</option>
                    </select>
                </div>
                <br> <br>
                <div class="inputBox">
                    <label for="qtd_volts">Voltagem</label>
                    <input required type="number" name="qtd_volts" id="qtd_volts" class="inputProduto" />
                </div>
                <br> <br>
                <div id="btn">
                <input id="button" name="submit" type="submit" value="Cadastrar">
                <br><br>
                <input id="button" type="reset" value="apagar">
               <br><br>
                <button id="button"><a href="../SessãoLogin/Registros.php">Voltar</a></button>
                </div>
        </form>
    </fieldset>
</body>
</html>